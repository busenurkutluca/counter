# Görev 1: Counter

İş yerinde çalışmaya başladıkça farklı ekiplerle tanışma şansına da eriştin. Hem Frontend tarafına hakim olmaya başladın hem de şirketini tanımaya başladın. Senin bu farkındalığın dikkatleri çekti.

Bu pazartesi yapılan toplantıda da güzel bir haber aldın. Seni React takımına aldılar.
Sana hızlıca bir eğitim vermeye başladılar ve senden bugün 6 farklı görevi tamamlamanı istediler.

İlk görevin bir sayac component'ini isterlere göre çalışır hale getirmek.

- İpucu: Bu sayacı oluşturmak için kaç tane state'e ihtiyaç var. Örn: https://player.vimeo.com/video/897678711
- İpucu: yeni bir state tanımlamak için: const [state, setState] = useState(BASLANGIC_DEGERI)
- İpucu: ternary operatör(üçleme) kullanabilirsin.
