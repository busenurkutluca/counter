import { useState } from 'react';
import './App.css';
import Sayac from './components/Sayac';

function App() {
  return (
    <>
      <Sayac />
    </>
  );
}

export default App;
